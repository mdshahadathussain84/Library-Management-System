LIBRARY MANAGEMENT SYSTEM - ANDROID STUDIO PROJECT
===================================================

Technology:
- Java
- XML
- SQLite
- Android Studio
- Minimum Android version: Android 6.0 (API 23)

IMPORTANT DEMO ADMIN LOGIN
Username: admin
Password: admin123

STUDENT ACCOUNT
Use Student Sign Up to create a student account, then use Student Sign In.

HOW TO OPEN
1. Extract LibraryManager.zip.
2. Open Android Studio.
3. Choose Open.
4. Select the extracted LibraryManager folder (the folder containing settings.gradle).
5. Wait for Gradle Sync to finish.
6. If Android Studio asks to install Android SDK 35 or Gradle components, accept.
7. Press the green Run button and select an emulator or connected Android phone.

FEATURES
ADMIN:
- Admin login
- Add books
- View and search books
- Delete books when they are not currently issued
- Approve or reject student issue/return requests
- View all transactions

STUDENT:
- Student sign up and sign in
- Browse and search books
- Send issue requests
- View personal book activity
- Request return of an issued book

RETURN PROCESS
1. Student sends a return request for an issued book.
2. Admin sees the request in Pending Requests.
3. Admin approves after physically receiving the book.
4. The book becomes available again.

NOTES
- This is an academic demo project. Passwords are stored as plain text in SQLite for simplicity; do not use this approach in a real production app.
- The first launch creates a local database and inserts sample books plus the demo admin account.
- Data is stored locally on the device/emulator.
- This project uses Android platform widgets and does not require third-party UI libraries.
