package com.example.librarymanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.database.Cursor;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(22, 55, 101);
    private static final int BLUE = Color.rgb(36, 72, 121);
    private static final int BG = Color.rgb(246, 248, 252);
    private static final int INK = Color.rgb(28, 42, 63);
    private DatabaseHelper db;
    private LinearLayout root, body;
    private int userId = -1;
    private String userName = "", userEmail = "", role = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DatabaseHelper(this);
        showWelcome();
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(INK); if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(4, 5, 4, 5); return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private EditText input(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint);
        e.setTextSize(15); e.setInputType(type); e.setPadding(16, 10, 16, 10);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE)); return e;
    }
    private void start(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        setContentView(root);
        TextView bar = text(title, 21, true); bar.setTextColor(Color.WHITE); bar.setBackgroundColor(NAVY);
        bar.setPadding(20, 18, 16, 18); root.addView(bar);
        ScrollView scroll = new ScrollView(this); body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(18, 14, 18, 22); scroll.addView(body); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }
    private void heading(String s) { body.addView(text(s, 20, true)); }
    private void note(String s) { TextView t=text(s,13,false); t.setTextColor(Color.DKGRAY); body.addView(t); }
    private void addButton(String s, Runnable r) { body.addView(button(s,r), new LinearLayout.LayoutParams(-1,-2)); }
    private void gap() { View v=new View(this); body.addView(v,new LinearLayout.LayoutParams(1,12)); }
    private void showWelcome() {
        start("Library Manager");
        TextView logo=text("📚",64,true); logo.setGravity(Gravity.CENTER); body.addView(logo);
        TextView title=text("Library Management System",25,true); title.setGravity(Gravity.CENTER); body.addView(title);
        note("Read  •  Learn  •  Grow"); body.getChildAt(body.getChildCount()-1).setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        gap(); addButton("Admin Login", this::showAdminLogin); gap();
        addButton("Student Sign In", this::showStudentLogin); gap();
        addButton("Student Sign Up", this::showSignup);
        gap();
        addButton("About Project & Our Team", this::showAboutProject);
        gap();
        note("A simple library app for students and administrators.");    }
    private void showAdminLogin() { loginForm("Admin Login", "admin"); }
    private void showStudentLogin() { loginForm("Student Sign In", "student"); }
    private void loginForm(String title, String loginRole) {
        start(title); heading("Welcome back!"); gap();
        EditText email=input(loginRole.equals("admin")?"Username":"Email", InputType.TYPE_CLASS_TEXT);
        EditText pass=input("Password", InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        body.addView(email); body.addView(pass); gap();
        addButton("Login", () -> {
            Cursor c=db.login(email.getText().toString().trim(),pass.getText().toString(),loginRole);
            if(c.moveToFirst()) { userId=c.getInt(0); userName=c.getString(1); userEmail=c.getString(2); role=c.getString(3); c.close(); if(role.equals("admin")) showAdminHome(); else showStudentHome(); }
            else { c.close(); toast("Invalid username/email or password"); }
        });
        if(loginRole.equals("admin"));
        else { gap(); addButton("Create Student Account",this::showSignup); }
        gap(); addButton("Back",this::showWelcome);
    }
    private void showSignup() {
        start("Student Sign Up"); heading("Create your account"); gap();
        EditText name=input("Full name",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText email=input("Email address",InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText pass=input("Create password",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        body.addView(name); body.addView(email); body.addView(pass); gap();
        addButton("Sign Up", () -> {
            String n=name.getText().toString().trim(), e=email.getText().toString().trim(), p=pass.getText().toString();
            if(n.isEmpty()||e.isEmpty()||p.length()<4){toast("Enter all details; password must be at least 4 characters");return;}
            if(db.registerStudent(n,e,p)){toast("Account created. Please sign in.");showStudentLogin();}
            else toast("This email is already registered");
        });
        gap(); addButton("Already have an account? Sign In",this::showStudentLogin);
        gap(); addButton("Back",this::showWelcome);
    }
    private void showAdminHome() {
        start("Admin Dashboard"); heading("Hello, "+userName+"!"); note("Manage your library easily."); gap();
        Cursor s=db.stats(); if(s.moveToFirst()) note("Total books: "+s.getInt(0)+"     Available: "+s.getInt(1)+"     Issued: "+s.getInt(2)); s.close(); gap();
        addButton("Add Book",this::showAddBook); gap(); addButton("All Books / Delete Books",this::showBooks); gap();
        addButton("Pending Requests",this::showAdminRequests); gap(); addButton("All Transactions",this::showAdminHistory); gap();
        addButton("Profile / Logout",this::showProfile);
    }
    private void showStudentHome() {
        start("Student Dashboard"); heading("Hello, "+userName+"!"); note("Welcome to your library."); gap();
        addButton("Browse All Books",this::showBooks); gap(); addButton("Search Books",this::showSearch); gap();
        addButton("My Books and History",this::showStudentHistory); gap(); addButton("Request Return",this::showReturnRequest); gap();
        addButton("Profile / Logout",this::showProfile);
    }
    private void showAddBook() {
        start("Add Book"); heading("Enter book details"); gap();
        EditText title=input("Book title",InputType.TYPE_CLASS_TEXT);
        EditText author=input("Author name",InputType.TYPE_CLASS_TEXT);
        EditText category=input("Category",InputType.TYPE_CLASS_TEXT);
        EditText count=input("Number of copies",InputType.TYPE_CLASS_NUMBER);
        body.addView(title);body.addView(author);body.addView(category);body.addView(count);gap();
        addButton("Save Book",()->{
            try {
                String t=title.getText().toString().trim(),a=author.getText().toString().trim(),c=category.getText().toString().trim();
                int n=Integer.parseInt(count.getText().toString());
                if(t.isEmpty()||a.isEmpty()||c.isEmpty()||n<1){toast("Please enter valid details");return;}
                if(db.addBook(t,a,c,n)){toast("Book added successfully");showAdminHome();} else toast("Could not add book");
            } catch(Exception ex){toast("Enter a valid number of copies");}
        });
        gap(); addButton("Back",this::showAdminHome);
    }
    private void showBooks() { showBookList(""); }
    private void showSearch() {
        start("Search Books"); EditText q=input("Search by title or author",InputType.TYPE_CLASS_TEXT); body.addView(q);
        addButton("Search",()->showBookList(q.getText().toString().trim()));
        gap(); addButton("Show All Books",()->showBookList(""));
    }
    private void showBookList(String query) {
        start("All Books"); EditText search=input("Search by title or author",InputType.TYPE_CLASS_TEXT); search.setText(query); body.addView(search);
        addButton("Search",()->showBookList(search.getText().toString().trim())); gap();
        Cursor c=db.books(query); boolean any=false;
        while(c.moveToNext()) {
            any=true; int id=c.getInt(0); String title=c.getString(1),author=c.getString(2),cat=c.getString(3); int total=c.getInt(4),avail=c.getInt(5);
            TextView item=text(title+"\n"+author+"  •  "+cat+"\nAvailable: "+avail+" / "+total,16,true);
            item.setBackgroundColor(Color.WHITE); item.setPadding(14,14,14,14); body.addView(item); gap();
            if(role.equals("student")) addButton("Request this book",()->{if(db.createRequest(userId,id,"ISSUE"))toast("Issue request sent to admin");else toast("Not available or request already exists");});
            if(role.equals("admin")) addButton("Delete this book",()->new AlertDialog.Builder(this).setTitle("Delete book?").setMessage(title).setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{if(db.deleteBook(id))toast("Book deleted");else toast("Cannot delete: book is currently issued");showBookList(query);}).show());
            gap();
        }
        c.close(); if(!any) note("No books found."); gap(); addButton("Back to Dashboard",role.equals("admin")?this::showAdminHome:this::showStudentHome);
    }
    private void showAdminRequests() {
        start("Pending Requests"); Cursor c=db.requests("PENDING"); boolean any=false;
        while(c.moveToNext()) {
            any=true; int id=c.getInt(0); String name=c.getString(1),title=c.getString(2),type=c.getString(3);
            TextView item=text(name+"\n"+title+"\nRequest: "+type,16,true); item.setBackgroundColor(Color.WHITE); item.setPadding(14,14,14,14); body.addView(item);
            addButton("Approve",()->{if(db.approveRequest(id))toast("Request approved");else toast("Unable to approve request");showAdminRequests();});
            addButton("Reject",()->{db.rejectRequest(id);toast("Request rejected");showAdminRequests();}); gap();
        }
        c.close(); if(!any)note("No pending requests."); gap(); addButton("Back",this::showAdminHome);
    }
    private void showReturnRequest() {
        start("Request Book Return"); heading("Your issued books"); Cursor c=db.studentRequests(userId); boolean any=false;
        while(c.moveToNext()) {
            int id=c.getInt(0); String title=c.getString(1),type=c.getString(2),status=c.getString(3);
            if(type.equals("ISSUE")&&status.equals("ISSUED")) {
                any=true; TextView item=text(title+"\nStatus: "+status,16,true); item.setBackgroundColor(Color.WHITE); item.setPadding(14,14,14,14); body.addView(item);
                addButton("Request Return",()->{if(db.createRequest(userId,bookIdForIssuedRequest(id),"RETURN"))toast("Return request sent to admin");else toast("Return request could not be sent");showReturnRequest();}); gap();
            }
        }
        c.close(); if(!any)note("You have no books waiting to be returned.");
        gap(); addButton("Back",this::showStudentHome);
    }
    private int bookIdForIssuedRequest(int requestId) {
        Cursor c=getContentResolver()==null?null:null;
        android.database.Cursor x= db.getReadableDatabase().rawQuery("SELECT book_id FROM requests WHERE id=?",new String[]{String.valueOf(requestId)});
        int id=x.moveToFirst()?x.getInt(0):-1; x.close(); return id;
    }
    private void showStudentHistory() {
        start("My Books and History"); Cursor c=db.studentRequests(userId); boolean any=false;
        while(c.moveToNext()) {
            any=true; TextView item=text(c.getString(1)+"\n"+c.getString(2)+"  •  "+c.getString(3)+"\nRequested: "+c.getString(4)+"  Due: "+c.getString(5),15,true);
            item.setBackgroundColor(Color.WHITE); item.setPadding(14,14,14,14); body.addView(item); gap();
        }
        c.close(); if(!any)note("No book activity yet."); gap(); addButton("Back",this::showStudentHome);
    }
    private void showAdminHistory() {
        start("All Transactions"); Cursor c=db.requests(null); boolean any=false;
        while(c.moveToNext()) {
            any=true; TextView item=text(c.getString(1)+"  •  "+c.getString(2)+"\n"+c.getString(3)+" / "+c.getString(4)+"\n"+c.getString(5),15,true);
            item.setBackgroundColor(Color.WHITE); item.setPadding(14,14,14,14); body.addView(item); gap();
        }
        c.close(); if(!any)note("No transactions yet."); gap(); addButton("Back",this::showAdminHome);
    }
    private void showProfile() {
        start("Profile"); heading(userName); note(userEmail); note("Account type: "+role.toUpperCase(Locale.ROOT)); gap();
        addButton("Logout",()->{userId=-1;userName="";userEmail="";role="";showWelcome();});
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }

    @Override public void onBackPressed() {
        if(userId<0) showWelcome();
        else if(role.equals("admin")) showAdminHome();
        else showStudentHome();
    }

    private void showAboutProject() {
        start("About Project & Our Team");

        heading("Library Management System");
        note("Brainware University");

        gap();
        heading("Our Team");

        note("1. MD Shahadat Hussain");
        note(   "BWU/MCA/25/147");

        note("2. Dipannita Das");
        note(   "BWU/MCA/25/163");

        note("3. Debangana Hui");
        note(   "BWU/MCA/25/160");

        note("4. Sayani Paul");
        note(   "BWU/MCA/25/164");

        note("5. Ayush Mishra");
        note(   "BWU/MCA/25/148");

        gap();
        addButton("Back to Home", this::showWelcome);
    }
}
