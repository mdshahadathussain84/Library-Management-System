package com.example.librarymanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "library_manager.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password TEXT, role TEXT)");
        db.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, category TEXT, total INTEGER, available INTEGER)");
        db.execSQL("CREATE TABLE requests(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, book_id INTEGER, type TEXT, status TEXT, request_date TEXT, due_date TEXT)");
        ContentValues admin = new ContentValues();
        admin.put("name", "Administrator");
        admin.put("email", "admin");
        admin.put("password", "admin123");
        admin.put("role", "admin");
        db.insert("users", null, admin);

        addSeedBook(db, "Java Programming", "Herbert Schildt", "Programming", 5);
        addSeedBook(db, "Python Programming", "Guido van Rossum", "Programming", 4);
        addSeedBook(db, "Data Structures", "Abhay Kumar", "Computer Science", 3);
        addSeedBook(db, "Database Systems", "Silberschatz", "Database", 4);
        addSeedBook(db, "Operating Systems", "Galvin", "Computer Science", 3);
    }

    private void addSeedBook(SQLiteDatabase db, String title, String author, String category, int count) {
        ContentValues v = new ContentValues();
        v.put("title", title); v.put("author", author); v.put("category", category);
        v.put("total", count); v.put("available", count);
        db.insert("books", null, v);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS requests");
        db.execSQL("DROP TABLE IF EXISTS books");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public boolean registerStudent(String name, String email, String password) {
        ContentValues v = new ContentValues();
        v.put("name", name); v.put("email", email); v.put("password", password); v.put("role", "student");
        return getWritableDatabase().insert("users", null, v) != -1;
    }

    public Cursor login(String email, String password, String role) {
        return getReadableDatabase().rawQuery(
            "SELECT id,name,email,role FROM users WHERE email=? AND password=? AND role=?",
            new String[]{email, password, role});
    }

    public Cursor books(String search) {
        String q = "%" + search + "%";
        return getReadableDatabase().rawQuery(
            "SELECT id,title,author,category,total,available FROM books WHERE title LIKE ? OR author LIKE ? ORDER BY title",
            new String[]{q, q});
    }

    public boolean addBook(String title, String author, String category, int total) {
        ContentValues v = new ContentValues();
        v.put("title", title); v.put("author", author); v.put("category", category);
        v.put("total", total); v.put("available", total);
        return getWritableDatabase().insert("books", null, v) != -1;
    }

    public boolean deleteBook(int id) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM requests WHERE book_id=? AND status='ISSUED'", new String[]{String.valueOf(id)});
        c.moveToFirst(); boolean hasIssued = c.getInt(0) > 0; c.close();
        if (hasIssued) return false;
        return getWritableDatabase().delete("books", "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public Cursor requests(String status) {
        return getReadableDatabase().rawQuery(
            "SELECT r.id,u.name,b.title,r.type,r.status,r.request_date,r.due_date " +
            "FROM requests r JOIN users u ON r.user_id=u.id JOIN books b ON r.book_id=b.id " +
            (status == null ? "" : "WHERE r.status=? ") + "ORDER BY r.id DESC",
            status == null ? null : new String[]{status});
    }

    public Cursor studentRequests(int userId) {
        return getReadableDatabase().rawQuery(
            "SELECT r.id,b.title,r.type,r.status,r.request_date,r.due_date FROM requests r " +
            "JOIN books b ON r.book_id=b.id WHERE r.user_id=? ORDER BY r.id DESC",
            new String[]{String.valueOf(userId)});
    }

    public boolean createRequest(int userId, int bookId, String type) {
        if ("ISSUE".equals(type)) {
            Cursor c = getReadableDatabase().rawQuery("SELECT available FROM books WHERE id=?", new String[]{String.valueOf(bookId)});
            boolean available = c.moveToFirst() && c.getInt(0) > 0; c.close();
            if (!available) return false;
        }
        String duplicateSql;
        if ("ISSUE".equals(type)) {
            duplicateSql = "SELECT COUNT(*) FROM requests WHERE user_id=? AND book_id=? AND ((type='ISSUE' AND status IN ('PENDING','ISSUED')) OR (type='RETURN' AND status='PENDING'))";
        } else {
            duplicateSql = "SELECT COUNT(*) FROM requests WHERE user_id=? AND book_id=? AND type='RETURN' AND status='PENDING'";
        }
        Cursor existing = getReadableDatabase().rawQuery(
            duplicateSql, new String[]{String.valueOf(userId), String.valueOf(bookId)});
        existing.moveToFirst(); boolean duplicate = existing.getInt(0) > 0; existing.close();
        if (duplicate) return false;

        ContentValues v = new ContentValues();
        v.put("user_id", userId); v.put("book_id", bookId); v.put("type", type);
        v.put("status", "PENDING"); v.put("request_date", java.text.DateFormat.getDateInstance().format(new java.util.Date()));
        v.put("due_date", "");
        return getWritableDatabase().insert("requests", null, v) != -1;
    }

    public boolean approveRequest(int requestId) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT book_id,type,status,user_id FROM requests WHERE id=?", new String[]{String.valueOf(requestId)});
        if (!c.moveToFirst() || !"PENDING".equals(c.getString(2))) { c.close(); return false; }
        int bookId = c.getInt(0); String type = c.getString(1); int userId = c.getInt(3); c.close();
        if ("ISSUE".equals(type)) {
            Cursor b = db.rawQuery("SELECT available FROM books WHERE id=?", new String[]{String.valueOf(bookId)});
            boolean ok = b.moveToFirst() && b.getInt(0) > 0; b.close();
            if (!ok) return false;
            db.execSQL("UPDATE books SET available=available-1 WHERE id=?", new Object[]{bookId});
            ContentValues v = new ContentValues(); v.put("status", "ISSUED");
            v.put("due_date", java.text.DateFormat.getDateInstance().format(new java.util.Date(System.currentTimeMillis() + 14L*24*60*60*1000)));
            db.update("requests", v, "id=?", new String[]{String.valueOf(requestId)});
        } else {
            db.execSQL("UPDATE books SET available=MIN(total,available+1) WHERE id=?", new Object[]{bookId});
            ContentValues returned = new ContentValues(); returned.put("status", "RETURNED");
            db.update("requests", returned, "user_id=? AND book_id=? AND type='ISSUE' AND status='ISSUED'",
                new String[]{String.valueOf(userId), String.valueOf(bookId)});
            db.update("requests", returned, "id=?", new String[]{String.valueOf(requestId)});
        }
        return true;
    }

    public boolean rejectRequest(int requestId) {
        ContentValues v = new ContentValues(); v.put("status", "REJECTED");
        return getWritableDatabase().update("requests", v, "id=? AND status='PENDING'", new String[]{String.valueOf(requestId)}) > 0;
    }

    public Cursor stats() {
        return getReadableDatabase().rawQuery(
            "SELECT (SELECT IFNULL(SUM(total),0) FROM books), (SELECT IFNULL(SUM(available),0) FROM books), " +
            "(SELECT COUNT(*) FROM requests WHERE status='ISSUED')", null);
    }
}
